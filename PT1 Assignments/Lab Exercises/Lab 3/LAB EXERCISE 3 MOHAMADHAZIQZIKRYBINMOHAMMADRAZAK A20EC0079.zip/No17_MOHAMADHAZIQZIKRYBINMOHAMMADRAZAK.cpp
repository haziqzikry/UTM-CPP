/* Name: Mohamad Haziq Zikry Bin Mohammad Razak */
/* Matrics Number: A20EC0079 */

#include <iostream>
using namespace std;
int main()
{
	float length= 2.5 ,width= 15.3 ; 						// Declare and set the variable
	float area; 	   										//Declare the variable
	
	area= length*width ;  									//Calculate the area
	cout <<"The area of a rectangle = " << area << endl; 	//Display the area of a rectangle
	
	return 0 ;
}
